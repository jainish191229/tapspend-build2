TAPSPEND PHONE-ONLY APK BUILD KIT

You need a GitHub account. This uses GitHub Actions to build the Android APK in the cloud.

1. Extract this ZIP on your phone using My Files.
2. In a browser, open https://github.com/new and create a NEW private repository named tapspend-build. Do not add a README/license/gitignore during creation.
3. In the repository, use Add file > Upload files. Upload TapSpendAndroidProject.zip from the extracted kit, then commit it to the main branch.
4. Create the workflow file: Add file > Create new file. In the filename box enter exactly:
   .github/workflows/build.yml
5. Open the build.yml file from this kit in a text editor, copy all its contents, paste them into GitHub's editor, and commit to main.
6. Open the repository's Actions tab. Select "Build TapSpend APK". Tap Run workflow, choose main, then Run workflow.
7. Wait for the run to finish successfully. Open that completed run, scroll to Artifacts, and download TapSpend-debug-apk. Extract the downloaded artifact ZIP; it contains the APK.
8. Open the APK in My Files and install it. If Android asks, allow My Files to install unknown apps, then retry. Only install your own build.

Notes:
- This requires internet and a GitHub account; GitHub may ask for account verification or impose usage limits.
- Keep the repository private because it contains your app source. Never publish passwords or secret keys.
- This creates a debug APK for testing, not a Play Store release.
- The app may need build fixes if dependencies or project settings fail. If the workflow fails, share the error text/screenshot and we can troubleshoot.
